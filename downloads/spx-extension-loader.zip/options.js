const DEFAULT_CATALOG_URL = 'https://raw.githubusercontent.com/iggr1/spx-extension-hub/main/catalog.json';
const input = document.getElementById('catalogUrl');
const status = document.getElementById('status');

document.getElementById('saveButton').addEventListener('click', save);
document.getElementById('resetButton').addEventListener('click', () => {
  input.value = DEFAULT_CATALOG_URL;
  save();
});

chrome.runtime.sendMessage({ type: 'LOADER_GET_CATALOG_URL' }, response => {
  input.value = response?.url || DEFAULT_CATALOG_URL;
});

function save() {
  status.textContent = 'Validando catálogo...';
  chrome.runtime.sendMessage({ type: 'LOADER_SET_CATALOG_URL', url: input.value.trim() }, response => {
    if (chrome.runtime.lastError) {
      status.textContent = chrome.runtime.lastError.message;
      return;
    }
    status.textContent = response?.ok ? `Catálogo salvo. ${response.catalog.modules.length} módulo(s) encontrado(s).` : response?.error || 'Falha ao salvar.';
  });
}
